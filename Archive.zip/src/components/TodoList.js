import { View, FlatList , Text, StyleSheet} from 'react-native';
import React, { useState } from 'react';
import TodoItem from './TodoItem';

const TodoList = ({ todos, onRemove }) => {
  return (
    <View>
      <FlatList
        data={todos}
        renderItem={({ item }) => (
          <TodoItem item={item} onRemove={onRemove} />
        )}
      />
    </View>
  );
};

export default TodoList;

const styles = StyleSheet.create({
    container: {
      //flex: 1,
      backgroundColor: '#fff',
      alignItems: 'center',
      justifyContent: 'center',
    },
  });
  