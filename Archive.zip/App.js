import { StatusBar } from "expo-status-bar";
import { Pressable, StyleSheet, Text, TextInput, View } from "react-native";
import TodoList from "./src/components/TodoList";
import { useState } from "react";
import nextId from "react-id-generator";

export default function App() {
  const [item, setItem] = useState("");
  const [items, setItems] = useState([
    { key: 'id0', text: 'Visit the Doctor' }
  ]);

  const handleRemove = id => {
    const copyItems = items.filter(item => item.key !== id);
    setItems(copyItems);
  };

  const handleAddItem = () => {
   if(item == ""){
    alert("Please enter todo item name")
   }
   else{
    setItem(item)
    const newItem = {
      key: nextId(),
      text: item
    };
    setItems ([...items, newItem]);
    setItem("")
   }
   
  }

  return (
    <>
      <View style={styles.container}>
        <View style={styles.form}>
          <TextInput
            style={{
              marginTop: 20,
              color: "#000",
              marginBottom: 20,
              borderBottomColor: "grey",
              borderWidth: 1,
              padding: 10
            }}
            placeholder="Enter Some Value"
            value={item}
            onChangeText={item => setItem(item)}
          />

          <Pressable style={{backgroundColor: 'grey', padding: 10, marginLeft: 10}} onPress={handleAddItem}>
            <Text>Save Item</Text>
          </Pressable>
        </View>
        <TodoList todos={items} onRemove={handleRemove} />
      </View>
    </>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: "#fff",
    alignItems: "center",
    justifyContent: "center",
    marginTop: 100,
  },
  form: {
    marginTop: 20,
    flexDirection: "row",
    justifyContent: "space-evenly",
    alignItems: "center",
  },
});
